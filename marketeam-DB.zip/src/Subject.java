import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Subject extends JFrame
{
    private JButton cancelButton;
    private JButton doneButton;
    private JTextField textField1;
    private JTextField textField2;
    private JRadioButton a2RadioButton;
    private JRadioButton a3RadioButton;
    private JRadioButton a4RadioButton;
    private JRadioButton a5RadioButton;
    private JPanel mainpanel;

    DATABASECLASS DB = new DATABASECLASS();

    public Subject()
    {
        setContentPane(mainpanel);
        setTitle("User_Info");
        setSize(500,250);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setVisible(true);

        cancelButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                dispose();
            }
        });
        doneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {

            }
        });
    }

    public void input_data()
    {
        gesipanDB Gesipan = new gesipanDB();
        Gesipan.subject_name_professor = textField1.getText();
        Gesipan.subject_info = textField2.getText();

        DB.inputGesipan(Gesipan);

    }
}
