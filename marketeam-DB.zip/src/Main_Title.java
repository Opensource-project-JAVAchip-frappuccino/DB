import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main_Title extends JFrame
{

    private JPanel panel1;
    private JButton MYINFOButton;
    private JButton LOGOUTButton;
    private JButton APPLYSTATUSButton;
    private JButton MATCHINGButton;
    private JLabel user_info_mini;
    private JComboBox comboBox1;
    private JTable table1;
    private JTable table2;
    private JButton MAKETEAMButton;

    UserDB User = new UserDB();

    public Main_Title(UserDB User)
    {
        setContentPane(panel1);
        setTitle("User_Info");
        setSize(1000,500);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setVisible(true);

        this.User = User;

        User_info_mini_setting();
        setComboBox1();

        LOGOUTButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                dispose();
                Login_Title new_login = new Login_Title();
            }
        });
        MYINFOButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                dispose();
                User_Info update = new User_Info();
            }
        });
    }

    private void createUIComponents()
    {
        // TODO: place custom component creation code here
    }

    private void User_info_mini_setting()
    {
        StringBuilder user_info_buf = new StringBuilder();

        user_info_buf.append("<html>");
        user_info_buf.append("이름 : " + User.name);
        user_info_buf.append(" <br>");
        user_info_buf.append("<html>");
        user_info_buf.append("학번 : " + Integer.toString(User.hakbun));
        user_info_buf.append(" <br>");
        user_info_buf.append("<html>");
        user_info_buf.append("학과 : " + User.major);
        user_info_buf.append(" <br>");
        user_info_buf.append("<html>");
        user_info_buf.append("학년 : " + Integer.toString(User.grade));
        user_info_buf.append(" <br>");

        user_info_buf.append("</html>");

        String user_info = new String(user_info_buf.toString());


        user_info_mini.setText(user_info);
    }

    public void setComboBox1()
    {
        String subjectname = new String("오픈소스 개발 프로젝트 (강재구)");

        comboBox1.addItem(subjectname);
    }
}
