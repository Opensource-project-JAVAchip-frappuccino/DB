public class gesipanDB
{
    String subject_name_professor = new String();
    String subject_info = new String();
    int teamnum;
}
