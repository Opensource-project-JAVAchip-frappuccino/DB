public class UserDB
{
    String name = new String();
    String major = new String();
    int hakbun;
    int password;
    int grade;
    int match_score;
    int [] match_var = new int[7]; // 팀장 발표 ppt 문서작성 프론트/백 코딩실력 동의여부
    boolean signup = false;
}

